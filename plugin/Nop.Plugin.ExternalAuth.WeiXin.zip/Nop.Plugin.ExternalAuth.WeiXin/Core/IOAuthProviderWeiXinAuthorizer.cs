﻿using Nop.Services.Authentication.External;

namespace Nop.Plugin.ExternalAuth.WeiXin.Core
{
    public interface IOAuthProviderWeiXinAuthorizer : IExternalProviderAuthorizer
    {
    }
}

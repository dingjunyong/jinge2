﻿
namespace Nop.Plugin.ExternalAuth.WeiXin.Core
{
    public static class Provider
    {
        public static string SystemName
        {
            get
            {
                return "ExternalAuth.WeiXin";
            }
        }
    }
}
